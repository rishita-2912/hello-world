module.exports = {
  assets: ["./src/assets/fonts/Roboto"],
};
