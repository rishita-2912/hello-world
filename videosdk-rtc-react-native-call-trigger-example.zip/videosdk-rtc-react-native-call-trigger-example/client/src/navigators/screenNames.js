export const SCREEN_NAMES = {
  Home: "homescreen",
  Meeting: "meetingscreen",
};
